"""Inferência de triagem na stack LEVE (produção): variante só-contexto, sem SBERT.

O modelo principal da tese (LR contexto+texto) precisa do embedding SBERT do título — stack
pesada. O runner de alertas e a app na nuvem correm a stack leve, por isso o treino grava
também a variante SÓ-CONTEXTO (`models/triage_context_lr.joblib`): volatilidade, momentum,
reação do dia, comprimento do título e setor. Honestidade: o texto que acompanha o score
identifica sempre a variante usada; os números da tese vêm da avaliação, não daqui.

Ausência graciosa: sem o ficheiro do modelo, `load_context_bundle` devolve None e quem chama
segue sem triagem (comportamento antigo intacto — integração off-by-default, ML_PLAN M5).
"""

from __future__ import annotations

import math
from pathlib import Path

import pandas as pd

from investigator.triage.dataset import SECTORS, event_features
from investigator.triage.explain import lr_group_contributions
from investigator.triage.features import context_block

_REPO = Path(__file__).resolve().parents[2]
DEFAULT_BUNDLE = _REPO / "models" / "triage_context_lr.joblib"


def load_context_bundle(path: str | Path = DEFAULT_BUNDLE) -> dict | None:
    """Carrega o bundle só-contexto; None se o ficheiro não existir (ausência graciosa)."""
    p = Path(path)
    if not p.exists():
        return None
    from investigator.triage.model import load_bundle  # import tardio (joblib/sklearn)

    return load_bundle(p)


# Setor em tempo de INFERÊNCIA para nomes que a watchlist tem e o corpus de treino não.
#
# ⚠️ Porque isto existe. O `SECTORS` de `dataset.py` é o mapa do CORPUS (14 tickers do FNSPID);
# a watchlist implantada tem doze nomes, e **AMD e NFLX não estão em nenhum dos dois**. Sem esta
# tabela, `SECTORS.get(t, "")` devolvia "" e o `context_block` produzia um one-hot de setor
# **todo a zeros** — um padrão que não existe em **nenhuma** das 79.753 linhas de treino, onde
# toda a linha tem exactamente um setor activo. Dois dos doze nomes implantados eram pontuados
# fora da distribuição, em silêncio.
#
# Não se toca no mapa canónico: ele descreve o corpus, é partilhado com a avaliação de
# recuperação, e alterá-lo mexeria em números congelados. Isto é uma decisão de IMPLANTAÇÃO e
# fica declarada como tal — é uma aproximação (nenhum dos dois esteve no treino) e a alternativa
# era pior.
DEPLOY_SECTORS: dict[str, str] = {"AMD": "tech", "NFLX": "tech"}


def deploy_sector(ticker: str) -> str:
    """O setor a usar na inferência: corpus primeiro, watchlist depois, "" em último."""
    t = ticker.upper()
    return SECTORS.get(t) or DEPLOY_SECTORS.get(t, "")


def score_context(bundle: dict, vol20: float, mom5: float, ret_event: float,
                  headline: str, ticker: str) -> tuple[float, list[tuple[str, float]]]:
    """Probabilidade calibrada + contribuições (XAI) a partir das features de contexto.

    Ticker fora de qualquer mapa → one-hot todo a zeros ("setor desconhecido"). O modelo pontua
    na mesma, mas **fora da distribuição de treino** — ver `DEPLOY_SECTORS`.
    """
    df = pd.DataFrame([{
        "vol20": vol20, "mom5": mom5, "ret_event": ret_event,
        "headline_len": float(len(headline)),
        "sector": deploy_sector(ticker),
    }])
    x, names = context_block(df)
    if names != bundle["feature_names"]:  # bundle velho vs features novas (guarda tipo R1)
        raise ValueError("Bundle incompatível com as features atuais — retreinar "
                         "(scripts/train_triage.py).")
    prob = float(bundle["calibrator"](bundle["model"].predict_proba(x)[:, 1])[0])
    contribs = lr_group_contributions(bundle["model"], x[0], bundle["feature_names"])
    return prob, contribs


def score_latest(bundle: dict, close: pd.Series, headline: str, ticker: str,
                 ) -> tuple[float, list[tuple[str, float]]] | None:
    """Score do dia mais recente da série de fechos; None se faltar histórico (fail-open).

    ⚠️ O guard do NaN foi acrescentado depois de o registo de produção o exigir, e a forma como
    apareceu vale a pena guardar. A 2026-08-04 a fonte de preços devolveu buracos em toda a
    watchlist, as features saíram NaN, e o `LogisticRegression` levantou `ValueError` — 21 vezes
    num dia, 25 no total. O ciclo continuava (o chamador apanha tudo e segue sem triagem), por
    isso nada se perdeu; mas no registo isso ficava como `error` com um stack trace, que é
    **indistinguível de uma avaria real**. Um dia sem preços não é um defeito do sistema, é uma
    condição do mundo, e tem de se ler como tal.

    `event_features` já devolve None quando falta histórico; o que não apanhava era histórico
    presente mas com furos. Agora falha aberto do mesmo modo, e a diferença é que o log passa a
    dizer "sem dados" em vez de rebentar.
    """
    feats = event_features(close, len(close) - 1)
    if feats is None:
        return None
    if any(v is None or (isinstance(v, float) and math.isnan(v))
           for v in (feats["vol20"], feats["mom5"], feats["ret_event"])):
        return None
    return score_context(bundle, feats["vol20"], feats["mom5"], feats["ret_event"],
                         headline, ticker)


def score_background(bundle: dict, close: pd.Series, ticker: str,
                     ) -> tuple[float, list[tuple[str, float]]] | None:
    """Risco de "fundo" do ticker HOJE, sem nenhuma notícia concreta (painel ao vivo).

    Mesmo modelo, mesmas features de contexto (volatilidade/momento/reação/setor); o título
    é uma string vazia (`headline_len=0`) — um placeholder honesto e explícito, não uma
    notícia inventada. Distingue-se sempre na UI de um score "para esta notícia".
    """
    return score_latest(bundle, close, "", ticker)
