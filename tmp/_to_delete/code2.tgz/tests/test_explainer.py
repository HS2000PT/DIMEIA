"""Testes do motor de explicação para o Gatilho 2 (notícia + precedentes)."""

from investigator.anomaly_detector.detector import AnomalyResult
from investigator.explanation_engine.explainer import explain_anomaly, explain_news_impact
from investigator.historical_kb.record import NewsRecord


def _precedents():
    return [
        (NewsRecord(date="2023-05-25", ticker="NVDA", headline="AI chips demand soars",
                    impacts={"1": 0.02, "3": 0.04, "5": 0.05}), 0.91),
        (NewsRecord(date="2023-06-13", ticker="NVDA", headline="New AI accelerator",
                    impacts={"1": 0.05, "3": 0.04, "5": 0.05}), 0.80),
    ]


def test_explica_impacto_com_precedentes():
    text = explain_news_impact("NVDA", "Nvidia raises outlook", _precedents(), horizon=3)
    assert "News alert for NVDA" in text
    assert "+4.00%" in text          # média de 0.04 e 0.04
    assert "sim 0.91" in text
    assert "not a price prediction" in text


def test_sem_precedentes():
    text = explain_news_impact("XYZ", "Algo novo", [], horizon=3)
    assert "No similar historical precedents" in text


def test_explica_anomalia_em_linguagem_simples():
    """Gatilho 1: z-score + leitura em linguagem simples para o não-especialista."""
    res = AnomalyResult(
        is_anomaly=True, z_score=7.61, last_return=0.1982,
        mean=-0.0092, std=0.0273, window=20, threshold=3.0,
    )
    text = explain_anomaly("TSLA", res)
    assert "TSLA" in text
    assert "+19.82% today" in text                           # o facto, legível num relance
    assert "z-score +7.61" in text
    assert "7.6 standard deviations" in text                 # rigor (mantém a estatística)
    assert "7.6× its typical daily swing" in text            # leitura em linguagem simples


def test_salto_apos_norma_plana_e_explicado_sem_z_inventado():
    res = AnomalyResult(
        is_anomaly=True, z_score=0.0, last_return=0.05,
        mean=0.0, std=0.0, window=20, threshold=3.0, zero_variance=True,
    )

    text = explain_anomaly("TEST", res)
    assert "flat 20-day baseline" in text
    assert "z-score is undefined" in text
    assert "z-score +0.00" not in text


def test_explicacao_fiel_aos_precedentes_recuperados():
    """Fidelidade (XAI): a explicação reflete EXATAMENTE os precedentes e scores recuperados."""
    precs = _precedents()
    text = explain_news_impact("NVDA", "Nvidia raises outlook", precs, horizon=3)
    for rec, score in precs:
        assert rec.date in text          # cada data aparece
        assert rec.ticker in text        # cada ticker aparece
        assert rec.headline in text      # cada título aparece
        assert f"sim {score:.2f}" in text  # o score exato recuperado aparece
    # nenhuma data/título inventado: o nº de linhas de precedente == nº de precedentes
    assert text.count("sim ") == len(precs)


def test_media_ignora_nan():
    precs = [
        (NewsRecord(date="2023-01-01", ticker="A", headline="h1",
                    impacts={"3": float("nan")}), 0.9),
        (NewsRecord(date="2023-01-02", ticker="A", headline="h2",
                    impacts={"3": 0.04}), 0.8),
    ]
    text = explain_news_impact("A", "consulta", precs, horizon=3)
    assert "+4.00%" in text   # média ignora o NaN → só 0.04
    assert "n/a" in text       # o precedente com NaN aparece como n/a na lista


def test_aviso_de_direcao_mista_quando_precedentes_divergem():
    """A lição do CS3 no produto: sinais mistos nos precedentes → aviso explícito."""
    mistos = [
        (NewsRecord(date="2023-01-01", ticker="A", headline="h1", impacts={"3": 0.05}), 0.9),
        (NewsRecord(date="2023-01-02", ticker="A", headline="h2", impacts={"3": -0.03}), 0.8),
    ]
    texto = explain_news_impact("A", "consulta", mistos, horizon=3)
    assert "BOTH directions" in texto

    concordantes = [
        (NewsRecord(date="2023-01-01", ticker="A", headline="h1", impacts={"3": 0.05}), 0.9),
        (NewsRecord(date="2023-01-02", ticker="A", headline="h2", impacts={"3": 0.02}), 0.8),
    ]
    texto2 = explain_news_impact("A", "consulta", concordantes, horizon=3)
    assert "BOTH directions" not in texto2


def test_direcao_unanime_e_descritiva_nunca_previsao():
    todos_sobem = [
        (NewsRecord(date="2023-01-01", ticker="A", headline="h1", impacts={"3": 0.05}), 0.9),
        (NewsRecord(date="2023-01-02", ticker="A", headline="h2", impacts={"3": 0.02}), 0.8),
    ]
    texto = explain_news_impact("A", "consulta", todos_sobem, horizon=3)
    assert "2 of 2 shown cases moved up" in texto
    assert "not a forecast" in texto
    todos_descem = [
        (NewsRecord(date="2023-01-01", ticker="A", headline="h1", impacts={"3": -0.05}), 0.9),
    ]
    texto2 = explain_news_impact("A", "consulta", todos_descem, horizon=3)
    assert "1 of 1 shown cases moved down" in texto2


def test_idade_dos_precedentes_so_com_today():
    precs = [
        (NewsRecord(date="2023-01-01", ticker="A", headline="h1", impacts={"3": 0.05}), 0.9),
    ]
    sem_idade = explain_news_impact("A", "consulta", precs, horizon=3)
    assert "ago)" not in sem_idade  # demo/tese: byte-igual ao histórico
    com_idade = explain_news_impact("A", "consulta", precs, horizon=3, today="2026-07-11")
    assert "(4y ago)" in com_idade  # 2023-01-01 → ~3,5 anos → arredonda a 4


def test_severidade_em_niveis_no_alerta_de_mercado():
    """Produto 2026-07-13: com o limiar de implantação em 1.5, o texto distingue os níveis
    (notable < strong < extreme) — 1.6 não pode ler-se como 3.2. Tokens de fidelidade
    ('Anomaly detected for', 'x this stock's typical daily swing') intactos."""
    from investigator.explanation_engine.explainer import severity_label

    assert severity_label(1.6) == "notable"
    assert severity_label(-2.4) == "strong"
    assert severity_label(3.0) == "extreme"

    def _res(z):
        return AnomalyResult(is_anomaly=True, z_score=z, last_return=0.03,
                             mean=0.0, std=0.01, window=20, threshold=1.5)

    assert "Notable move" in explain_anomaly("TSLA", _res(1.6))
    assert "Strong move" in explain_anomaly("TSLA", _res(2.4))
    extremo = explain_anomaly("TSLA", _res(7.61))
    assert "Extreme move" in extremo
    assert "7.6× its typical daily swing" in extremo  # token de sempre


def test_sector_context_line_descreve_o_dia_sem_prever():
    from investigator.explanation_engine.explainer import sector_context_line

    # pares do setor mexeram na MESMA direção ≥1% e em dimensão COMPARÁVEL → padrão setorial
    moves = {"NVDA": -0.045, "AMD": -0.038, "MSFT": -0.012, "AAPL": -0.002, "JPM": 0.01}
    linha = sector_context_line("NVDA", moves)
    assert "technology" in linha and "AMD -3.8%" in linha and "MSFT -1.2%" in linha
    assert "similar amount" in linha
    assert "AAPL" not in linha  # <1% não conta como "mexeu"
    assert "JPM" not in linha   # outro setor nunca entra

    # pares parados → movimento específico da empresa
    sozinho = sector_context_line("NVDA", {"NVDA": -0.045, "AMD": 0.001, "MSFT": -0.002})
    assert "specific to NVDA" in sozinho

    # sem pares no mapa/na varredura → sem linha (fail-quiet)
    assert sector_context_line("NVDA", {"NVDA": -0.045}) == ""
    assert sector_context_line("ZZZZ", {"ZZZZ": -0.05, "NVDA": -0.04}) == ""

    # direção OPOSTA nos pares não conta como confirmação setorial
    oposto = sector_context_line("NVDA", {"NVDA": -0.045, "AMD": 0.03})
    assert "specific to NVDA" in oposto


def test_attach_sector_safe_anexa_e_e_failopen():
    from scripts.run_alerts import _attach_sector_safe

    base = "🔺 Anomaly detected for NVDA: +5.00% today"
    com = _attach_sector_safe("NVDA", base, {"NVDA": 0.05, "AMD": 0.04})
    assert base in com and "Sector check:" in com
    sem = _attach_sector_safe("NVDA", base, {})  # sem movimentos → intacto
    assert sem == base


def test_attach_news_context_com_e_sem_noticia():
    from investigator.explanation_engine.explainer import attach_news_context

    base = "🔺 Anomaly detected for TSLA: +5.00% today"
    com = attach_news_context(base, "Tesla recalls vehicles", news_date="2026-07-10",
                              today="2026-07-11")
    assert base in com
    assert 'Possible explanation (1d ago): "Tesla recalls vehicles"' in com
    sem = attach_news_context(base, None)
    assert "No relevant news found in the last 48h" in sem
    assert base in sem


def test_sector_line_nao_pode_contradizer_a_decomposicao():
    """Regressão de um defeito REAL, medido no histórico do canal.

    A linha do setor olhava só para a DIREÇÃO dos pares. Em 9 de 30 alertas dizia "Looks
    sector-wide, not company-specific" e a linha seguinte, da decomposição de dois fatores,
    dizia "Most of this move was specific to the company". O caso que o denunciou: AMD a cair
    13,23% com os pares a cair 2,0%, 1,9% e 1,4%.

    Um alerta que se contradiz duas linhas depois destrói a confiança que o resto do sistema
    tenta construir, e o utilizador não tem como saber qual das duas frases acreditar.
    """
    from investigator.explanation_engine.explainer import sector_context_line

    # O caso real da AMD: mesma direção, dimensão totalmente diferente.
    linha = sector_context_line(
        "AMD", {"AMD": -0.1323, "TSLA": -0.020, "NVDA": -0.019, "AMZN": -0.014}
    )
    assert "sector-wide" not in linha, "não pode afirmar setorial quando o movimento é 6x maior"
    assert "far less" in linha, f"tem de dizer que os pares mexeram muito menos: {linha}"

    # Mesma direção E dimensão parecida: aí sim é legítimo chamar-lhe setorial.
    parecido = sector_context_line(
        "AMD", {"AMD": -0.021, "TSLA": -0.020, "NVDA": -0.019, "AMZN": -0.024}
    )
    assert "similar amount" in parecido
    assert "far less" not in parecido
