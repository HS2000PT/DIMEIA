\babel@toc {portuguese}{}\relax 
\contentsline {lstlisting}{\numberline {3.1}{\ignorespaces O cálculo do \emph {z}-score. A fatia \texttt {[-window-1:-1]} exclui o próprio dia da janela que define a sua norma.}}{26}{lstlisting.77}%
\contentsline {lstlisting}{\numberline {3.2}{\ignorespaces Os \textbf {dois} testes que impedem o futuro de entrar nas entradas. O primeiro exige que duas séries com futuros diferentes dêem entradas iguais; o segundo, que é o que fecha o argumento, exige ao mesmo tempo que o \emph {rótulo} mude.}}{41}{lstlisting.142}%
\providecommand \tocbasic@end@toc@file {}\tocbasic@end@toc@file 
